## <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Hi.gif" width="29px"> I'm Aris187 ID
<p align="center">
<img src="https://raw.githubusercontent.com/A187ID/AR15BOT/main/aris/A187.jpg" width="230" height="230"/>
</p>
<br>



<p align="center">
<a href="#"><img title="😎MASLENT😎" src="https://img.shields.io/badge/ICHI-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/ichi-lent"><img title="Author" src="https://img.shields.io/badge/AUTHOR-MASLENT GANS-orange.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://www.codefactor.io/repository/github/A187ID/AR15BOT"><img title="Rating" src="https://www.codefactor.io/repository/github/ichi-lent/ichi/badge/main"></a>
</p>
<p align="center">
<a href="https://github.com/ichi-lent/ichi/followers"><img title="Followers" src="https://img.shields.io/github/followers/ICHI?color=blue&style=flat-square"></a>
<a href="https://github.com/ichi-lent/ichi/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/ichi-lent/ichi?color=red&style=flat-square"></a>
<a href="https://github.com/ichi-lent/ichi/network/members"><img title="Forks" src="https://img.shields.io/github/forks/ichi-lent/ichi?color=red&style=flat-square"></a>
<a href="https://github.com/ichi-lent/ichi/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/ichi-lent/ichi?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FA187ID%2FAR15BOT&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
</p>
<img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Developer.gif" alt="Mario Game" width="600" />
<div align="center">
<details>
 
</details>

XXX 𝗧𝗵𝗮𝗻𝗸𝘀 𝗙𝗼𝗿 𝗠𝗵𝗮𝗻𝗸𝗕𝗮𝗿𝗕𝗮𝗿

XXX WARNING
MAU RE-UPLOAD SCRIPT? KASIH NAMA/LINK CHANEL SAYA.... DILARANG UBAH INFO!!!

XX NOTE:> 
SCRIPTNYA JANGAN DI JUAL/BELI KAN.. SCRIPT INI 100% GRATIS BUAT KALIAN PENGGUNA TERMUX
</div>

XXX ALAT DAN BAHAN <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Mario_Hello_Big.gif" width="29px">
Siapin alat dan bahannya.
```bash
> niat
> 2 handphone (1 buat jalanin sc, 1 buat scan kode qr kak)
> jaringan internet kenceng,kuota+
> penyimpanan yang memadai
> aplikasi whatsapp
> aplikasi termux
> kopi+rokok ;v
```

### CARA INSTALLNYA  <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/hmm.gif" width="29px">
Script ini di modifikasi sama saya sendiri MaslentGans.
```bash
> kalo lu belum punya apk termux, download di playstore
> masuk ke apk termux lalu ketik dibawah ini!
> git clone https://github.com/ICHI-LENT/ichi
> cd ichi-lent/ichi
> bash install.sh
> node index js
> Tinggal scan kode qr yeee...done
```


Ket: Aktiv 24 jam

## DONASI <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/coin.gif" width="29px">
* [`Donasi MASLENT`](08165466368) VIPUL


## SOSIAL MEDIA ADMIN <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/powerup.gif" width="29px">

* [`Youtube Admin`](MAS LENT YT)
* [`Instagram Admin`](https://instagram.com/_maslent11)
* [`WhatsApp Admin `](https://wa.me/+628165466368)
## THANKS TO <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Handshake.gif" width="60px">

* [`fdciabdul`](https://github.com/fdciabdul/termux-whatsapp-bot)

* [`MhankBarBar`](https://github.com/MhankBarBar/whatsapp-bot)
<img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Mario_Gameplay.gif" alt="Mario Game" width="600" />


