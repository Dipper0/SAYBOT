# SAYBOT

<p align="center">
  <a href="https://github.com/SlavyanDesu"><img src="https://avatars3.githubusercontent.com/u/28254882?s=400&u=25765902db0b709938966cf4127ac11af5eafb5d&v=4" height="128" width="128" /></a>

## FEATURES  <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Earth.gif" width="29px">

| SAYBOT.        |                   Feature        |
| :-----------:  | :------------------------------: |
|       ✅       | Sticker Creator                  |
|       ✅       | Nulis                            |
|       ✅       | add                              |
|       ✅       | kick                             |
|       ✅       | demote                           |
|       ✅       | promote                          |
|       ✅       | bc                               |
|       ✅       | welcome                          |
|       ✅       | Youtube Downloader               |
|       ✅       | simi                             |
|       ✅       | left                             |
|       ✅       | setpp                            |
|       ✅       | group buka/tutup                 |
|       ✅       | nsfwloli                         |
|       ✅       | loli                             |
|       ✅       | tts                              |
|       ✅       | tiktokstalk                      |
|       ✅       | tiktok                           |
|       ✅       | tagall                           |
|       ✅       | clearall                         |
|       ✅       | block                            |
|       ✅       | unblock                          |
|       ✅       | sound                            |
|       ✅       | tsticker                         |
|       ✅       | nulis                            |
|       ✅       | meme                             |
|       ✅       | memeindo                         |
|       ✅       | ocr                              |
|       ✅       | clone                            |
|       ✅       | bc                               |
|       ✅       | leave                            |
|       ✅       | url2img                          |
|       ✅       | wait                             |
|                                                   |


